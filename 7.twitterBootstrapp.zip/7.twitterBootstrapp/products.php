<!DOCTYPE html>
<html lang="en">
<head>
  <title>Arkademy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
  <script src="js/jquery.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
</head>

<body>

  <?php
  include 'koneksidb.php';
  ?>

  <div class="col-sm-6" style="padding-top: 20px; padding-bottom: 20px;">
    <h3 align="center">Tabel Products</h3>
    <hr>
<div class="form-group">
  <button onClick="top.location='Kategori.php'" type="button" class="btn btn-primary">Tabel Kategori</button>
  <button onClick="top.location='index.php'" type="button" class="btn btn-primary">Hasil Query</button>
</div> 



   <table id="datatable" class="table table-striped table-bordered">
      <table id="datatable" class="table table-striped table-bordered datatab">
        <thead>
          <tr>
            <th>id</th>
            <th>category_id</th>
            <th>name</th>                         
          </tr>
        </thead>  
        <tbody>            
         <?php 
          $query = mysql_query("SELECT * FROM products ORDER BY id");
          $no = 1;
          while ($data = mysql_fetch_assoc($query)) 
          {
          ?>
            <tr>
              
              <td><?php echo $data['id']; ?></td> 
              <td><?php echo $data['category_id']; ?></td>         
              <td><?php echo $data['name']; ?></td>
            </tr>
          <?php               
          } 
          ?>
        </tbody>
      </table>          
  </div> 

</body>
  <script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
  <script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
  <script>
  $(document).ready(function() {
    $('.datatab').dataTable();
  } );
  </script>
</html>